/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Mockito injection internals.
 */
package org.mockito.internal.configuration.injection;
