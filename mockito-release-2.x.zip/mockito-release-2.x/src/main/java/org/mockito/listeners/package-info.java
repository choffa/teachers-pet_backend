/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Public classes relative to the listener APIs.
 */
package org.mockito.listeners;
